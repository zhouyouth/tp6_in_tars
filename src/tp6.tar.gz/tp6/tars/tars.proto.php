<?php

return array(
    'appName' => 'PHP',
    'serverName' => 'tp6',
    'objName' => 'obj',
    'withServant' => true,//决定是服务端,还是客户端的自动生成
    'jceFiles' => array(
        'jce/example.jce'
    ),
    'srcPath' => '',//这里用来autoload
    'namespace' => '',
);