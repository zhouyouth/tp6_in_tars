
# Introduction
Let thinkphp6.0 framework happily run in tars
* Support package release
* Support service survival report (service registration)



# usage

* Clone project
* Installation dependencies `composer install`
* package `composer run-script deploy`
* Upload tars platform

# Configuration instructions

* The service name needs to be configured correctly in ./tars/tars.proto.php
* Do not use the port number issued by the tars platform, configure it in the way of thinkphp

#Thanks
[TARS Foundation Official Website](https://tarscloud.org/foundation/index)<br>
[swoole](https://github.com/swoole/swoole-src)<br>
[dpp2009](https://github.com/dpp2009/thinkphpInTars)



